import React from 'react'

export function Courses() {
  return (
    <div>
        <h1>Estamos en Cursos</h1>
    </div>
  )
}
